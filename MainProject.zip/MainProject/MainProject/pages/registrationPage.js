import {getUserForm} from "../feautures/loginForm/loginForm";
import styles from './registrationPage.module.css'
import {image} from "../components/image";

export const registrationPage = () =>{
    const reg = document.createElement('div')
    reg.classList.add(styles.container)
    reg.append(image('/logo.png'))
    reg.append(getUserForm())
    return reg;
}